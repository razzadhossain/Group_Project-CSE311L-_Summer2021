<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BasicSetting extends Model
{
    protected $table = 'basic_settings';

    protected $guarded = [''];
}
